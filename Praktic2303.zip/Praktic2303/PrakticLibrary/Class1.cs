﻿using System.Text;

namespace PrakticLibrary
{
    /// <summary>
    /// 
    /// </summary>
    public class StringCircle
    {
        /// <summary>
        /// Получение строки от 1..N.
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public string GetSequence(int size)
        {
            if (size < 0)
            {
                throw new ArgumentException("the value cannot be less than 0");
            }

            var returnString = "";
            for (int result = 1; result <= size; result++)
            {
                if (result != size)
                {
                    returnString += result.ToString() + ", ";
                }
                else
                {
                    returnString += result.ToString() + ".";
                }
            }

            return returnString;
        }

        const int minSize = 50; //максимальный размер стороны

        /// <summary>
        /// Создание круга из # размером N
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        /// <exception cref="Exception"></exception>
        public string[,] GetCircle(int size)
        {
            if (size > minSize)
            {
                throw new ArgumentOutOfRangeException("Range massive");
            }

            if (size % 2 == 0)
            {
                throw new ArgumentException("must be an odd number");
            }

            var middleCircle = size / 2;
            var outCircle = new string[minSize, minSize];

            for (var i = 0; i < size; i++)
            {
                for (var j = 0; j < size; j++)
                {
                    if ((j == 0 && i == 0) ||
                        (j == size - 1 && i == 0) ||
                        (j == 0 && i == size - 1) ||
                        (j == size - 1 && i == size - 1))
                    {
                        outCircle[i, j] = " ";
                    }
                    else
                    {
                        outCircle[i, j] = (i == middleCircle && j == middleCircle)
                            ? " "
                            : "#";

                    }
                }
            }

            return outCircle;
        }

        /// <summary>
        /// 2 вариант получения круга из # размером N
        /// </summary>
        /// <param name="sizeCircle"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        /// <exception cref="Exception"></exception>
        public List<StringBuilder> GetCircleTwo(int sizeCircle)
        {
            if (sizeCircle > minSize)
            {
                throw new ArgumentException("Exceeded the maximum size");
            }

            if (sizeCircle % 2 == 0)
            {
                throw new Exception("must be an odd number");
            }

            int middleCircle = sizeCircle / 2;
            List<StringBuilder> outCircle = new List<StringBuilder>();
            string patternString = string.Join("#", new string[sizeCircle + 1]);


            StringBuilder patternBuilder1 = new StringBuilder(patternString); // целые
            StringBuilder patternBuilder2 = new StringBuilder(GetPattern(patternString, sizeCircle)); // начало\конец
            StringBuilder patternBuilder3 = new StringBuilder(GetMiddlePattern(patternString, sizeCircle)); // середина


            for (int i = 0; i < sizeCircle; i++)
            {
                if (i == 0 || i == sizeCircle - 1)
                {
                    outCircle.Add(patternBuilder2);
                }
                else if (i == middleCircle)
                {
                    outCircle.Add(patternBuilder3);
                }
                else
                {
                    outCircle.Add(patternBuilder1);
                }
            }

            return outCircle;
        }

        private string GetPattern(string pattern, int size)
        {
            StringBuilder result = new StringBuilder(pattern);
            result.Replace("#", " ", 0, 1);
            result.Replace("#", " ", size - 1, 1);

            return result.ToString();
        }

        private string GetMiddlePattern(string pattern, int size)
        {
            StringBuilder result = new StringBuilder(pattern);
            result.Replace("#", " ", size / 2, 1);

            return result.ToString();
        }
    }
}