﻿using PrakticLibrary;
using System.Runtime.CompilerServices;
using System.Text;

/// <summary>
/// Считывание числа с консоли
/// </summary>
/// <param name="message"></param>
/// <returns></returns>
static int ReadNumberFromConsole(string message)
{
    Console.WriteLine(message);

    return Convert.ToInt32(Console.ReadLine());
}

try
{
    var generator = new StringCircle();

    Console.WriteLine("Task 1");
    var n = ReadNumberFromConsole("Enter size string");
    Console.WriteLine(generator.GetSequence(n));

    Console.WriteLine("\nTask 2");
    n = ReadNumberFromConsole("Enter size range massive");

    //string[,] Circle = p.GetCircle(N);

    //for (int i = 0; i < N; i++)
    //{
    //    for (int j = 0; j < N; j++)
    //    {
    //        Console.Write(Circle[i, j]);
    //    }
    //    Console.WriteLine();
    //}

    DisplayCircle(n, generator.GetCircleTwo(n));

    DisplayCircle(n, generator.GetCircleTwo(30));
    
    Console.ReadLine();
}
catch (InvalidCastException)
{
    Console.WriteLine("You didn't enter a number");
    throw;
}
catch (IndexOutOfRangeException)
{
    Console.WriteLine("The size is too big");
	throw;
}
catch (Exception ex)
{
    Console.WriteLine($"Error {ex.Message}");
}

static void DisplayCircle(int n, List<StringBuilder> circle)
{
    for (int i = 0; i < n; i++)
    {
        Console.WriteLine(circle[i]);
    }
}